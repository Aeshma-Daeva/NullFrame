# Portable kit qualification and limits

This bundle contains the existing October24 Windows inventory executable and
the current dependency-free Python inventory sources. The executable has not
been rebuilt. Previous personal Windows VM verification covered32 tests,
standalone operation without Python on PATH, a path with spaces, report
replacement, an unelevated token and an offline interactive run.
A separate non-admin account and actual Centec hardware remain field checks.

The samples/inventory-sample.json is a declaration-only example produced from
InventoryRecord.create. No machine discovery was performed: detected is empty,
observed_at and all permissions are unknown. It is not a real machine report.
Create a fresh report on each authorized node.

Current local check:194/194 coordinator tests pass, including4 packaging tests
and the verifier/direct-launch report-symlink regressions (RED to GREEN).
The source acceptance tests exercise reproducible archives, extraction with
spaces, real Linux inventory, manifest verification, refusal of tampered/missing/
unlisted code and symlinked report directories. The launcher verifies before
importing inventory code. A failed verification prevents inventory execution.

The inventory is descriptive and offline. It installs no packages, starts no
worker/service, grants no permissions and uploads no data. Preserve unknown
hardware/permissions; review raw reports locally before any transfer.
Checksums establish integrity against the separately retained known-good archive,
not author identity. Keep that archive/checksum for re-extraction recovery.

Demian observer/subprocess engineering is qualified separately and is not
included as a deployable environment in this inventory bundle. Scientific
learning/adaptation, Windows neural execution, remote deployment and24/7
operation are not established by inventory or packaging tests.
