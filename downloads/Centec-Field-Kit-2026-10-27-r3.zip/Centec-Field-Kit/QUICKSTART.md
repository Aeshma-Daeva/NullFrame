# Centec portable operator kit — October 29, 2026

This archive contains the previously qualified standalone Windows inventory
release and the same dependency-free Python inventory sources for Linux.
It does not contain research states, grants, API keys, model environments or
an observer service. It needs no download or package installation.

## Windows
1. Extract this archive into a writable local folder, including a path with spaces.
2. Compare its SHA-256 with the separately retained known-good checksum.
   PowerShell: `Get-FileHash .\Centec-Field-Kit-2026-10-27-r3.zip -Algorithm SHA256`.
3. Extract Windows-Inventory.zip, then open Centec-Inventory.cmd.
   That release checks its executable digest. It needs no Python.
4. Enter a friendly machine label, broad location and ownership.
5. Review machine-report.json beside the Windows launcher. Keep the raw report local.

The existing personal VM release was qualified with an unelevated token.
A separate non-administrator account and actual Centec hardware remain field checks.
A Python installation is optional on Windows; if already available it can run
`py -3 -I -B verify.py` to verify the complete extracted outer kit.

## Linux
Requires an existing Python3.11+ interpreter. From the extracted Centec-Field-Kit:
```bash
python3 -I -B verify.py
python3 -I -B inventory.py --name centec-node-1 --location lab --ownership institutional --output reports/machine-report.json
```
Or run `python3 -I -B inventory.py` for interactive questions; default output is
machine-report.json in the current directory. Prefer reports/ so kit verification
continues to distinguish code from output. Use a writable folder; permission
failures should be recorded, not worked around with administrator access.

Checksums detect accidental changes; they do not establish who authorized code.
Retain the known-good archive/checksum separately. On a failed check re-extract
that archive into a fresh folder. Existing reports are never part of recovery.
Copy selected reports to the project-owned evidence location after local review;
do not auto-export them.

## Thursday checklist
- Record OS, architecture, CPU/RAM/storage and GPU facts, preserving unknowns.
- Record actual operator account/elevation and tool failures.
- Record permissions separately: inventory, execution, GPU, network, transfer,
  unattended operation. Every execution grant remains unknown by default.
- Inventory does not enroll a node or start a workload.
- Rehearse fixed computation only on an explicitly permitted node using its
  separately qualified runner. This kit contains inventory only.
- Record differences from the personal VM, report location, blockers and next action.

## Offline example and qualification
samples/inventory-sample.json is a declaration-only example, not a discovered
machine: detected is empty and all permissions/observation time are unknown.
QUALIFICATION.md records the qualified scope and remaining field checks.
The r3 verifier and launcher refuse symlinks in reports/ before any output.

## Baseline and remaining work
Inventory release: existing October24 Windows build, unchanged here.
Local Linux observer subprocess: qualified separately with wall/CPU/address-space/
file/log limits, source pins and replay. Windows observer compatibility, VPS/GPU
placement, parent-death cleanup, remote authentication, live model routing and
24/7 operation remain separate objectives. No observed dynamics are a learning claim.
