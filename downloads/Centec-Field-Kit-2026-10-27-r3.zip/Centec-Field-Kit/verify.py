"""Verify the extracted operator kit before running its inventory launcher."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys


def verify(root):
    root = Path(root).resolve()
    manifest = root/"MANIFEST.json"
    if manifest.is_symlink() or manifest.stat().st_size > 65536:
        raise ValueError("invalid manifest")
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result: raise ValueError("duplicate manifest field")
            result[key] = value
        return result
    data = json.loads(manifest.read_bytes(), object_pairs_hook=pairs)
    if not isinstance(data, dict) or set(data) != {"schema_version","files"} or data["schema_version"] != 1:
        raise ValueError("manifest schema")
    files = data["files"]
    if not isinstance(files, dict) or not 1 <= len(files) <= 64:
        raise ValueError("manifest file limit")
    total = 0
    for name, digest in files.items():
        path = PurePosixPath(name)
        if (not isinstance(name, str) or path.is_absolute() or ".." in path.parts
            or str(path) != name or "\\" in name or name == "MANIFEST.json"
            or not isinstance(digest, str) or not re.fullmatch("[a-f0-9]{64}", digest)):
            raise ValueError("invalid manifest entry")
        target = root/name
        for part in (target, *target.parents):
            if part == root: break
            if part.is_symlink(): raise ValueError("symlink refused")
        if not target.is_file(): raise ValueError("missing kit file")
        size = target.stat().st_size
        total += size
        if size > 8*1024*1024 or total > 9*1024*1024:
            raise ValueError("kit size limit")
        with target.open("rb") as stream:
            raw = stream.read(8*1024*1024+1)
        if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError("kit checksum mismatch")
    # Extra reports are local outputs, never importable kit code.
    for path in root.rglob("*"):
        if path.is_symlink(): raise ValueError("symlink refused")
        if path.relative_to(root).parts[0] == "reports":
            continue
        if path.is_file() and path.relative_to(root).as_posix() not in {*files,"MANIFEST.json"}:
            raise ValueError("unlisted kit file")
    return len(files)


if __name__ == "__main__":
    try:
        count = verify(Path(__file__).resolve().parent)
    except (OSError, ValueError, TypeError, RecursionError):
        print("Kit verification failed. Re-extract the known-good archive.", file=sys.stderr)
        raise SystemExit(1)
    print(f"Verified {count} kit files.")
