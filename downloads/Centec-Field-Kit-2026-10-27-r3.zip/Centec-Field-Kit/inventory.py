import sys
import importlib.util
from pathlib import Path
sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
try:
    spec = importlib.util.spec_from_file_location("kit_verifier", root / "verify.py")
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    verifier.verify(root)
except Exception:
    print("Kit verification failed; inventory was not started.", file=sys.stderr)
    raise SystemExit(1)
sys.path.insert(0, str(root / "src"))
from centec_compute.inventory import main
raise SystemExit(main())
