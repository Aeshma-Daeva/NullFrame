from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
from typing import Mapping, Sequence, TextIO

from .discovery import SystemProbe, apply_discovery
from .model import InventoryRecord


def write_report_atomic(
    path: Path,
    payload: Mapping[str, object],
) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            suffix=".tmp",
            delete=False,
            newline="\n",
        ) as temporary:
            temporary_path = Path(temporary.name)
            json.dump(
                payload,
                temporary,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            temporary.write("\n")
            temporary.flush()
            os.fsync(temporary.fileno())

        os.replace(temporary_path, destination)
        temporary_path = None
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def _read_answer(
    prompt: str,
    input_stream: TextIO,
    output_stream: TextIO,
) -> str:
    print(prompt, end="", file=output_stream, flush=True)
    line = input_stream.readline()
    if line == "":
        raise EOFError("interactive input ended")
    return line.strip()


def collect_interactive(
    input_stream: TextIO,
    output_stream: TextIO,
) -> dict[str, str]:
    print(
        "Centec machine inventory (offline, no administrator access).",
        file=output_stream,
    )
    print(
        "Exact resource amounts are discovered automatically; unknown is valid.",
        file=output_stream,
    )

    while True:
        name = _read_answer("Machine name: ", input_stream, output_stream)
        try:
            InventoryRecord.create(name, "pending", "unknown")
        except ValueError:
            print("Invalid machine name. Please try again.", file=output_stream)
            continue
        break

    while True:
        location = _read_answer(
            "Broad location (home/lab/office): ",
            input_stream,
            output_stream,
        )
        try:
            InventoryRecord.create(name, location, "unknown")
        except ValueError:
            print("Invalid location. Please try again.", file=output_stream)
            continue
        break

    while True:
        ownership = _read_answer(
            "Ownership (personal/institutional/unknown): ",
            input_stream,
            output_stream,
        ).casefold()
        try:
            InventoryRecord.create(name, location, ownership)
        except ValueError:
            print("Invalid ownership. Please try again.", file=output_stream)
            continue
        break

    availability = _read_answer(
        "Availability estimate (optional, Enter to skip): ",
        input_stream,
        output_stream,
    )
    notes = _read_answer(
        "Notes or restrictions (optional, Enter to skip): ",
        input_stream,
        output_stream,
    )

    declarations = {
        "name": name,
        "location": location,
        "ownership": ownership,
    }
    if availability:
        declarations["availability"] = availability
    if notes:
        declarations["notes"] = notes
    return declarations


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="centec-inventory",
        description=(
            "Create a local machine inventory report. Resource amounts are "
            "discovered automatically; uncertain optional details may be omitted."
        ),
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Prompt for declarations; selected automatically when no arguments are given",
    )
    parser.add_argument("--name", help="Friendly machine name")
    parser.add_argument(
        "--location",
        help="Broad location such as home, lab, or office",
    )
    parser.add_argument(
        "--ownership",
        choices=("personal", "institutional", "unknown"),
        help="Who owns or controls the machine",
    )
    parser.add_argument(
        "--availability",
        help="Optional plain-language availability estimate",
    )
    parser.add_argument(
        "--notes",
        help="Optional uncertainty, constraint, or operator note",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("machine-report.json"),
        help="Report path (default: machine-report.json)",
    )
    return parser


def main(
    argv: Sequence[str] | None = None,
    *,
    probe: SystemProbe | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    input_stream = stdin or sys.stdin
    output_stream = stdout or sys.stdout
    error_stream = stderr or sys.stderr
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    interactive = not raw_argv or "--interactive" in raw_argv
    args = _parser().parse_args(raw_argv)

    if interactive:
        try:
            declarations = collect_interactive(input_stream, output_stream)
        except EOFError:
            print(
                "input ended before inventory declarations were complete",
                file=error_stream,
            )
            return 2
        name = declarations["name"]
        location = declarations["location"]
        ownership = declarations["ownership"]
        declared = {
            key: declarations[key]
            for key in ("availability", "notes")
            if key in declarations
        }
    else:
        name = args.name
        location = args.location
        ownership = args.ownership
        declared = {
            key: value
            for key, value in {
                "availability": args.availability,
                "notes": args.notes,
            }.items()
            if value is not None
        }

    try:
        record = InventoryRecord.create(
            display_name=name or "",
            location=location or "",
            ownership=ownership or "",
            declared=declared,
        )
    except ValueError as error:
        print(f"invalid inventory declaration: {error}", file=error_stream)
        return 2

    apply_discovery(record, probe or SystemProbe())

    try:
        write_report_atomic(args.output, record.to_dict())
    except OSError as error:
        print(
            f"could not write inventory report: {type(error).__name__}",
            file=error_stream,
        )
        return 1

    print(
        f"wrote inventory for {record.node_id} to {args.output}",
        file=output_stream,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
