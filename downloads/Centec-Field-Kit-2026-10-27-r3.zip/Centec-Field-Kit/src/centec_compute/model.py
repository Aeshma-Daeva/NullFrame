from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Mapping
import re
import unicodedata


SCHEMA_VERSION = 1
PROBE_VERSION = "inf01.inventory.v1"

PERMISSION_KEYS = (
    "inventory",
    "worker_execution",
    "gpu_use",
    "remote_access",
    "unattended_execution",
    "artifact_transfer",
    "internet_access",
    "active_security_testing",
)

OWNERSHIP_VALUES = frozenset({"personal", "institutional", "unknown"})


def _node_slug(display_name: str) -> str:
    normalized = unicodedata.normalize("NFKD", display_name.strip().casefold())
    ascii_name = normalized.encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]+", "-", ascii_name).strip("-")


@dataclass
class InventoryRecord:
    schema_version: int
    node_id: str
    display_name: str
    location: str
    ownership: str
    permission: dict[str, str]
    detected: dict[str, Any]
    declared: dict[str, Any]
    discovery: dict[str, Any]

    @classmethod
    def create(
        cls,
        display_name: str,
        location: str,
        ownership: str,
        declared: Mapping[str, Any] | None = None,
    ) -> "InventoryRecord":
        clean_name = display_name.strip()
        node_id = _node_slug(clean_name)
        if not node_id:
            raise ValueError("display_name must contain a letter or number")

        clean_location = location.strip()
        if not clean_location:
            raise ValueError("location must not be empty")

        if ownership not in OWNERSHIP_VALUES:
            allowed = ", ".join(sorted(OWNERSHIP_VALUES))
            raise ValueError(f"ownership must be one of: {allowed}")

        return cls(
            schema_version=SCHEMA_VERSION,
            node_id=node_id,
            display_name=clean_name,
            location=clean_location,
            ownership=ownership,
            permission={key: "unknown" for key in PERMISSION_KEYS},
            detected={},
            declared=deepcopy(dict(declared or {})),
            discovery={
                "observed_at": "unknown",
                "probe_version": PROBE_VERSION,
                "diagnostics": [],
            },
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "node_id": self.node_id,
            "display_name": self.display_name,
            "location": self.location,
            "ownership": self.ownership,
            "permission": deepcopy(self.permission),
            "detected": deepcopy(self.detected),
            "declared": deepcopy(self.declared),
            "discovery": deepcopy(self.discovery),
        }
