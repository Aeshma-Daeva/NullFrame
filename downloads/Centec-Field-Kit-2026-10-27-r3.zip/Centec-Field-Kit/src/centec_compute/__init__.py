"""Centec INF-01 experimental-computing primitives."""

__version__ = "0.1.0"
