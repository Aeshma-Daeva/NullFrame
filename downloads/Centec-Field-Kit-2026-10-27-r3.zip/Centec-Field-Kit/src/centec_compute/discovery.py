from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping
import csv
import ctypes
import os
import platform
import shutil
import subprocess

from .model import InventoryRecord


UNKNOWN = "unknown"

TOOL_CANDIDATES: Mapping[str, tuple[str, ...]] = {
    "python": ("python3", "python"),
    "git": ("git",),
    "docker": ("docker",),
    "podman": ("podman",),
    "ssh": ("ssh",),
    "powershell": ("pwsh", "powershell"),
    "wsl": ("wsl",),
    "nvidia_smi": ("nvidia-smi",),
}


def _memory_gib() -> float:
    if platform.system().casefold() == "windows":
        class MemoryStatus(ctypes.Structure):
            _fields_ = [
                ("length", ctypes.c_ulong),
                ("memory_load", ctypes.c_ulong),
                ("total_phys", ctypes.c_ulonglong),
                ("avail_phys", ctypes.c_ulonglong),
                ("total_page_file", ctypes.c_ulonglong),
                ("avail_page_file", ctypes.c_ulonglong),
                ("total_virtual", ctypes.c_ulonglong),
                ("avail_virtual", ctypes.c_ulonglong),
                ("avail_extended_virtual", ctypes.c_ulonglong),
            ]

        status = MemoryStatus()
        status.length = ctypes.sizeof(MemoryStatus)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            raise OSError("GlobalMemoryStatusEx failed")
        total_bytes = status.total_phys
    else:
        total_bytes = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")

    return round(total_bytes / (1024**3), 2)


def _storage_free_gib() -> float:
    anchor = Path.cwd().anchor or "."
    return round(shutil.disk_usage(anchor).free / (1024**3), 2)


def _run_command(command: list[str], timeout: float) -> str:
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=True,
        timeout=timeout,
    )
    return completed.stdout


def _default_probes() -> dict[str, Callable[[], object]]:
    return {
        "os_family": platform.system,
        "os_release": platform.release,
        "architecture": platform.machine,
        "cpu_model": platform.processor,
        "logical_cores": os.cpu_count,
        "ram_gib": _memory_gib,
        "storage_free_gib": _storage_free_gib,
    }


class SystemProbe:
    def __init__(
        self,
        probes: Mapping[str, Callable[[], object]] | None = None,
        which: Callable[[str], str | None] = shutil.which,
        now: Callable[[], datetime] | None = None,
        runner: Callable[[list[str], float], str] = _run_command,
    ) -> None:
        self._probes = dict(probes or _default_probes())
        self._which = which
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._runner = runner

    def _safe(
        self,
        name: str,
        diagnostics: list[str],
    ) -> object:
        try:
            value = self._probes[name]()
        except Exception as error:
            diagnostics.append(f"probe.{name}.failed:{type(error).__name__}")
            return UNKNOWN

        if value is None or value == "":
            return UNKNOWN
        return value

    def _tool_path(self, candidates: tuple[str, ...]) -> str | None:
        for candidate in candidates:
            try:
                path = self._which(candidate)
            except Exception:
                return None
            if path:
                return path
        return None

    def _discover_gpus(
        self,
        nvidia_smi_path: str | None,
        diagnostics: list[str],
    ) -> list[dict[str, object]]:
        if nvidia_smi_path is None:
            return []

        command = [
            nvidia_smi_path,
            "--query-gpu=name,memory.total,driver_version",
            "--format=csv,noheader,nounits",
        ]
        try:
            output = self._runner(command, 3.0)
        except Exception as error:
            diagnostics.append(
                f"probe.nvidia_smi.failed:{type(error).__name__}"
            )
            return []

        rows = list(csv.reader(output.splitlines()))
        parsed: list[dict[str, object]] = []
        try:
            for row in rows:
                if len(row) != 3:
                    raise ValueError("unexpected column count")
                name, memory_mib, driver_version = (item.strip() for item in row)
                if not name or not driver_version:
                    raise ValueError("missing value")
                parsed.append(
                    {
                        "name": name,
                        "vram_gib": round(float(memory_mib) / 1024, 2),
                        "driver_version": driver_version,
                    }
                )
        except (TypeError, ValueError):
            diagnostics.append("probe.nvidia_smi.malformed")
            return []

        return parsed

    def observed_at(self) -> str:
        return self._now().astimezone(timezone.utc).isoformat()

    def discover(self) -> tuple[dict[str, object], list[str]]:
        diagnostics: list[str] = []
        os_family = self._safe("os_family", diagnostics)
        if isinstance(os_family, str) and os_family != UNKNOWN:
            os_family = os_family.casefold()

        tool_paths = {
            key: self._tool_path(candidates)
            for key, candidates in TOOL_CANDIDATES.items()
        }
        detected: dict[str, object] = {
            "os": {
                "family": os_family,
                "release": self._safe("os_release", diagnostics),
                "architecture": self._safe("architecture", diagnostics),
            },
            "cpu": {
                "model": self._safe("cpu_model", diagnostics),
                "logical_cores": self._safe("logical_cores", diagnostics),
            },
            "ram_gib": self._safe("ram_gib", diagnostics),
            "storage_free_gib": self._safe("storage_free_gib", diagnostics),
            "tools": {
                key: path is not None for key, path in tool_paths.items()
            },
            "gpus": self._discover_gpus(
                tool_paths["nvidia_smi"],
                diagnostics,
            ),
        }
        return detected, diagnostics


def apply_discovery(
    record: InventoryRecord,
    probe: SystemProbe,
) -> InventoryRecord:
    detected, diagnostics = probe.discover()
    record.detected = detected
    record.discovery["observed_at"] = probe.observed_at()
    record.discovery["diagnostics"] = diagnostics
    return record
